from turtle import Turtle , Screen
from paddle import Paddle
import time
from ball import Ball

panel = Screen()
panel.setup(800,600)
panel.title("PONG_Neutron style")
panel.bgcolor("Black")
Pad1 = Paddle(350,0)
Pad2 = Paddle(-350,0)
ball1 = Ball()


panel.listen()
panel.onkey(Pad1.go_up,"Up")
panel.onkey(Pad1.go_down,"Down")
panel.onkey(Pad2.go_up,"w")
panel.onkey(Pad2.go_down,"s")

while True:
    time.sleep(0.1)
    ball1.move_it()
    if(ball1.ycor()>280):
        ball1.bounce_y()
    if(ball1.ycor() < -280):
        ball1.bounce_y()
    if(ball1.xcor() >380):
        Pad2.score += 1
        time.sleep(2)
        ball1.goto(0, 0)
    if (ball1.xcor() < -380):
        Pad1.score += 1
        time.sleep(2)
        ball1.goto(0,0)
    if(ball1.distance(Pad1)<50 and ball1.xcor()>330):
        ball1.bounce_x()
    if (ball1.distance(Pad2) < 50 and ball1.xcor() < -330):
        ball1.bounce_x()

panel.exitonclick()