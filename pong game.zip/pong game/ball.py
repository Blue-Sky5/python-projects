from turtle import Turtle


class Ball(Turtle):
    x_pass = 10
    y_pass = 10

    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("White")
        self.up()
        x_pass = 10
        y_pass = 10

    def move_it(self):
        self.goto(self.xcor()+self.x_pass,self.ycor()++self.y_pass)

    def bounce_x(self):
        self.x_pass*=-1
    def bounce_y(self):
        self.y_pass*=-1