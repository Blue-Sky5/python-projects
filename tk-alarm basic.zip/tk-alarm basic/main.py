import  math
#-------------------------consts--------------------#
PINK = "#ff3377"
RED = "#ff0000"
GREEN = "#1aff1a"
YELLOW = "#ffff00"
BG = "#f7e3af"
FONT = ("Segoe UI",20,"bold")
#-----------------------Time------------------------#
sec = 0
min = 0
#------------------------button---------------------#
def buffer_a():
    sumup = int(txtmin.get())*60 + int(txtsec.get())
    countdown(sumup)

def countdown(sumup):
    min_t = math.floor(sumup/60)
    sec_t = sumup % 60
    if sec_t > 9 and min_t>=0:
        canvas0.itemconfig(timerset,text = f"{min_t}:{sec_t}")
        bg_gif.config(format = f"gif -index {59-sec_t}")
        canvas0.itemconfig(picset, image = bg_gif)
        panel.after(1000,countdown,sumup-1)
    elif sec_t >= 0 and sec_t < 10 and min_t>=0:
        canvas0.itemconfig(timerset, text=f"{min_t}:0{sec_t}")
        panel.after(1000, countdown, sumup-1)
        bg_gif.config(format=f"gif -index {60 - sec_t}")
        canvas0.itemconfig(picset, image=bg_gif)


#------------------------UI------------------------#
from tkinter import *

panel = Tk()
panel.title("                                                          Timer Mode")
panel.minsize(width=500, height=500)
panel.resizable(False, False)
bg_gif = PhotoImage(file = "C:\\Users\\amn_n\\Desktop\\python projects\\alarm\\one.gif",format = f"gif -index {59-sec}")
under_image = PhotoImage(file = "C:\\Users\\amn_n\\Desktop\\python projects\\alarm\\two.png")

canvas0 = Canvas(width = 300,height = 300 , bg = BG ,highlightthickness = 0)
picset = canvas0.create_image(150,150,image = bg_gif)
timerset = canvas0.create_text(150 , 110,text = f"{min}:{sec}" ,fill = "black",font = FONT)
canvas1 = Canvas(width=500, height = 100 ,bg = BG , highlightthickness = 0)
canvas1.create_image(250,50,image = under_image)
panel.config(bg = BG)
txtmin = Entry()
txtmin.insert(END, '0')
txtsec = Entry()
txtsec.insert(END, '5')
button1 = Button(text ="Start",bg=BG,border = 0,highlightthickness = 5,command = buffer_a)
button2 =Button(text ="Reset",bg=BG,border=0,highlightthickness = 5)
label1 = Label(text = "min:",bg=BG)
label2 = Label(text = "sec: ",bg = BG)

#....................
canvas0.place(x = 100 , y = 0)
canvas1.place(x = -10, y = 300)
button2.place(x = 350, y = 330)
button1.place(x = 300, y = 330)
label1.place(x = 15, y = 325)
txtmin.place(x = 55, y = 325)
label2.place(x = 15, y = 350)
txtsec.place(x = 55, y = 350)




panel.mainloop()