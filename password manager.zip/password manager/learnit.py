from tkinter import *

#-------------------file handle-----------------------------#




#---------------Save password-------------------------------#
from tkinter import messagebox

def validate_save(a):
    if(len(a[0])<3):
        return 0
    elif(len(a[4])<8):
        return 0
    else:
        return 1


def password_enc(string_p):
    step = 16
    ans = ""
    for letter in string_p:
        letter = chr(((ord(letter) + step) % 126))
        ans += letter
    return ans

def password_Dec(string_p):
    step = 16
    ans = ""
    for letter in string_p:
        letter = ((ord(letter) - step) % 126)
        if letter >= 0:
            ans += chr(letter)
        else:
            ans += chr(letter+126)
    return ans


def save():
    file_p = open("C:\\Program Files\\Pass_The_Pass\\res.txt", "a")
    temp = [plat_form.get(),"|",Username.get(),"|",password.get()]
    if validate_save(temp):
        a = messagebox.askokcancel(title = "confirm",message = "Save these data?")
        if a:
         temp[4] = password_enc(temp[4])
         for i in temp:
            file_p.write(i)
         file_p.write("\n")
         file_p.close()
         messagebox.showinfo(title="Save Procedure", message="Password successfully saved")
    else:
        messagebox.showerror(title="error", message="invalid platform or password")
    plat_form.delete(0,END)
    Username.delete(0,END)
    password.delete(0,END)

#-------------------------load-----------------------------#
def load():
    temp_string = plat_form.get()
    temp_ans1 = ""
    temp_ans2 = " "
    if len(temp_string) < 3:
        messagebox.showerror("error","invalid platform")
    else:
        file_p = open("C:\\Program Files\\Pass_The_Pass\\res.txt", "r")
        a = file_p.readlines()
        b = []
        for i in a:
            b = i.split("|")
            if len(b)>2 and b[0] == temp_string:
                temp_ans1 = password_Dec(b[2])[0:-1]
                temp_ans2 = b[1]
        file_p.close()
        if len(temp_ans1) >= 8:
            Username.insert(0,temp_ans2)
            password.insert(0,temp_ans1)
            messagebox.showinfo("success","info successfully loaded")
        else:
            messagebox.showerror("error","platform not found")


#-------------------clear----------------------------------#
def clear():
    plat_form.delete(0, END)
    Username.delete(0, END)
    password.delete(0, END)
#----------------UI----------------------------------------#
x = "N/A"
main_window = Tk()
main_window.iconbitmap("C:\\Program Files\\Pass_The_Pass\\myIcon.ico")
main_window.title("Pass_The_Pass")
main_window.minsize(height=500 , width= 800)
main_window.resizable(False , False)
main_canvas = Canvas(height = 500 , width = 800)
main_image = PhotoImage(file = "C:\\Program Files\\Pass_The_Pass\\bg2.png")
main_canvas.create_image(0 ,0,image = main_image ,anchor=NW)
text_canvas = main_canvas.create_text(200, 150)
main_canvas.itemconfig(text_canvas, text="Platform : ")
text_canvas2 = main_canvas.create_text(200, 190)
main_canvas.itemconfig(text_canvas2, text="Username:")
text_canvas3 = main_canvas.create_text(200, 230)
main_canvas.itemconfig(text_canvas3, text="Password:")
text_canvas4 = main_canvas.create_text(200, 270)
main_canvas.itemconfig(text_canvas4, text="Strength:")

label1 = Label(text="N/A",bg='White', fg='Black')
but1 = Button()
but1.config(text = "Find",width=10,highlightthickness = 0,bg="#f4f1de",command = load)
but2 = Button()
but2.config(text = "Save",width=10,highlightthickness = 0,bg="#f4f1de",command = save)
but3 = Button()
but3.config(text = "Clear",width=10,highlightthickness = 0,bg="#f4f1de",command = clear)

plat_form = Entry()
plat_form.config(width = 30)
plat_form.focus()
Username = Entry()
Username.config(width = 30)
password = Entry()
password.config(width = 30)



main_canvas.place(x = 0 , y = 0)
plat_form.place(x = 250, y= 140)
Username.place(x = 250, y= 180)
password.place(x = 250, y= 220)
but1.place(x = 200, y= 320)
but2.place(x = 280, y= 320)
but3.place(x = 360, y= 320)
label1.place(x = 300 , y = 260)

main_window.mainloop()